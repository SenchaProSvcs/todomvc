# Spine.js TodoMVC app


## Getting started

[CoffeeScript](http://coffeescript.org) is required to compile this application if you make changes to the files in the `src` folder.


### Compile

Open Terminal in this folder.

- `cake build` to compile once

- `cake watch` to compile on save


## Credit

Created by [Sindre Sorhus](https://github.com/sindresorhus)
