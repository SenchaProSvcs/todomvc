# jQuery TodoMVC app

## Credit

Created by [Sindre Sorhus](https://github.com/sindresorhus)
