define({
	// TODO: Deal with singular vs. plural
	itemsLeft: {
		zero: '<strong></strong> items left',
		one: '<strong></strong> item left',
		many: '<strong></strong> items left'
	},
	filter: {
		all: 'All',
		active: 'Active',
		completed: 'Completed'
	},
	clearCompleted: 'Clear completed'
});
