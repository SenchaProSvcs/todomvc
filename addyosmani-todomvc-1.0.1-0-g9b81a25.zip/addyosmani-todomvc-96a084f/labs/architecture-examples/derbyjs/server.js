require('derby').run(__dirname + '/lib/server', 3003);
