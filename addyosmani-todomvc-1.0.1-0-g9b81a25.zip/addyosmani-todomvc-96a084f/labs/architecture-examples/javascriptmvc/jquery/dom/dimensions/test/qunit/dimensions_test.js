module("jquery/dom/dimensions");




test("outerHeight and width",function(){
	$("#qunit-test-area").html("//jquery/dom/dimensions/test/qunit/curStyles.micro",{})
})
