//we probably have to have this only describing where the tests are
steal
 .plugins("jquery/event/destroyed")  //load your app
 .plugins('funcunit/qunit')  //load qunit
 .then("destroyed_test")
 
